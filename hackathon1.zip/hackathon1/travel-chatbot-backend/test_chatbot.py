import requests

print("🤖 Travel Chatbot (type 'exit' to quit)\n")

url = "http://127.0.0.1:5001/chat"

while True:
    user_input = input("You: ").strip()
    if user_input.lower() == "exit":
        print("Goodbye! 👋")
        break

    data = {"message": user_input}
    try:
        response = requests.post(url, json=data)
        bot_reply = response.json().get("response", "No reply from bot.")
        print(f"Bot: {bot_reply}\n")
    except Exception as e:
        print(f"Bot: Error connecting to server: {e}\n")
