import os
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import google.generativeai as genai

# Load environment variables from .env
load_dotenv()

# Initialize Flask
app = Flask(__name__)
CORS(app)

# Configure Gemini AI with your API Key
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
genai.configure(api_key=GEMINI_API_KEY)

# Choose lightweight model for faster, cheaper responses
model = genai.GenerativeModel("gemini-2.0-flash-lite")

# System prompt to focus bot on travel/tourism answers
SYSTEM_PROMPT = """
You are a friendly travel assistant. Answer travel-related questions
about destinations, sightseeing, activities, food, hotels, and best time to visit.
Keep your answers concise (2-3 sentences max).
Politely decline off-topic questions.
"""

def get_gemini_response(message: str) -> str:
    """
    Send user's message to Gemini AI and return concise travel reply.
    """
    try:
        chat = model.start_chat()
        chat.send_message(SYSTEM_PROMPT)
        response = chat.send_message(message)
        reply = response.text.strip()
        return reply if reply else "Sorry, I couldn't process your request."
    except Exception as e:
        return f"Error: {str(e)}"

@app.route("/chat", methods=["POST"])
def chat():
    try:
        data = request.get_json()
        user_message = data.get("message", "").strip()

        if not user_message:
            return jsonify({"response": "Please enter a valid message."}), 400

        # Simple rule for greetings
        if user_message.lower() in ["hi", "hello", "hey"]:
            return jsonify({"response": "Hello! 👋 How can I assist you with travel or tourism today?"})

        # Call Gemini AI for all other messages
        reply = get_gemini_response(user_message)
        return jsonify({"response": reply})

    except Exception as e:
        return jsonify({
            "response": "Sorry, there was an error processing your request.",
            "error": str(e)
        }), 500

if __name__ == "__main__":
    app.run(debug=True, port=5001)
