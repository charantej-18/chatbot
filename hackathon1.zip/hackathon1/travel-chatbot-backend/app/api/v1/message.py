from fastapi import APIRouter
from pydantic import BaseModel
from app.services.gemini_service import get_gemini_response

router = APIRouter()

class MessageRequest(BaseModel):
    message: str
    language: str = "en"

class MessageResponse(BaseModel):
    reply: str

@router.post("/message", response_model=MessageResponse)
def send_message(request: MessageRequest):
    reply = get_gemini_response(request.message)
    return {"reply": reply}
