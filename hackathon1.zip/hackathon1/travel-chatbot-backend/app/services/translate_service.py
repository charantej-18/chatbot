from googletrans import Translator

translator = Translator()

def translate_text(text: str, dest_lang: str) -> str:
    return translator.translate(text, dest=dest_lang).text
