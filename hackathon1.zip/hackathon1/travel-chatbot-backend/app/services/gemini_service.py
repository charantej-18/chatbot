# app/services/gemini_service.py

from app.core.config import GEMINI_API_KEY

def get_gemini_response(message: str) -> str:
    """
    Mocked Gemini response for travel queries.
    Returns a concise reply without using the real Gemini API.
    """
    # You can customize mock replies based on the message
    travel_replies = {
        "paris": "Paris is famous for the Eiffel Tower, museums, and cafes. Best time to visit: April–June.",
        "london": "London offers the Tower of London, Buckingham Palace, and Thames River cruises. Best time: May–September.",
        "new york": "New York is known for Times Square, Central Park, and Broadway shows. Best time: April–June or September–November."
    }

    msg_lower = message.lower()
    for city in travel_replies:
        if city in msg_lower:
            return travel_replies[city]

    # Default mock reply
    return f"Mock reply: Here’s some information about '{message}' for travelers."
