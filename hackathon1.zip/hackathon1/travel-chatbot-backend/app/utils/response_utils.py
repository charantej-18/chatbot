def clean_response(response: str) -> str:
    return response.strip()
