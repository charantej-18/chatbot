def build_travel_prompt(user_message: str) -> str:
    return f"Answer concisely about travel: {user_message}"
