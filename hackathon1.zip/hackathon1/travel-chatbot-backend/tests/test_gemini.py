from app.services.gemini_service import get_gemini_response

def test_gemini_response():
    reply = get_gemini_response("Best tourist spots in London")
    assert isinstance(reply, str)
