from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_send_message():
    response = client.post("/api/v1/message", json={"message": "Tell me about Paris"})
    assert response.status_code == 200
    assert "reply" in response.json()
