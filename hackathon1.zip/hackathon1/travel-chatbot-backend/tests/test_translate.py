from app.services.translate_service import translate_text

def test_translation():
    text = translate_text("Hello", "es")
    assert text.lower() in ["hola", "hola!"]
