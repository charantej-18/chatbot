const chatBox = document.getElementById("chat-box");
const userInput = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");
const suggestions = document.querySelectorAll(".suggestion");
const darkModeToggle = document.getElementById("darkModeToggle");
const fromLang = document.getElementById("fromLang");
const toLang = document.getElementById("toLang");

const BACKEND_URL = "http://127.0.0.1:5001/chat"; // Flask backend

// Add message to chat
function addMessage(message, sender = "bot") {
  const msg = document.createElement("div");
  msg.classList.add("message", sender === "user" ? "user-message" : "bot-message");
  msg.textContent = message;

  chatBox.appendChild(msg);
  chatBox.scrollTop = chatBox.scrollHeight;

  // Auto TTS for bot replies
  if (sender === "bot") {
    speakText(message);
  }
}

// Text-to-Speech function
function speakText(text) {
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = toLang.value; // Bot replies in target language
  speechSynthesis.speak(utterance);
}

// Function to send user message to backend
async function sendMessage() {
  const message = userInput.value;
  if (message.trim()) {
    addMessage(message, "user");
    userInput.value = "";

    try {
      const res = await fetch(BACKEND_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
      });

      const data = await res.json();
      const botReply = data.response || "Sorry, I didn’t get that.";
      addMessage(botReply, "bot");
    } catch (err) {
      addMessage("⚠️ Error connecting to server.", "bot");
      console.error(err);
    }
  }
}

// Send button click
sendBtn.addEventListener("click", sendMessage);

// ✅ Send message on Enter key
userInput.addEventListener("keypress", (event) => {
  if (event.key === "Enter") {
    event.preventDefault();
    sendMessage();
  }
});

// Quick suggestion click
suggestions.forEach(btn => {
  btn.addEventListener("click", async () => {
    const text = btn.textContent;
    addMessage(text, "user");

    try {
      const res = await fetch(BACKEND_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });

      const data = await res.json();
      const botReply = data.response || "Sorry, I didn’t get that.";
      addMessage(botReply, "bot");
    } catch (err) {
      addMessage("⚠️ Error connecting to server.", "bot");
    }
  });
});

// Dark mode toggle
darkModeToggle.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
});
